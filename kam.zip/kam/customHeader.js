import React, {Component} from 'react';

export default class CustomHeader extends Component {
    constructor(props) {
        super(props);

        this.state = {
            ascSort: 'inactive',
            descSort: 'inactive',
            noSort: 'inactive'
        };

        props.column.addEventListener('sortChanged', this.onSortChanged.bind(this));
    }

    componentDidMount() {
        this.onSortChanged();
    }

    render() {
        console.log(this.props,'HAY')
        let menu = null;
        if (this.props.enableMenu) {
            menu =
                <div ref={(menuButton) => { this.menuButton = menuButton; }}
                    className="customHeaderMenuButton"
                    onClick={this.onMenuClicked.bind(this)}>
                    <i className={`fa ${this.props.menuIcon}`}></i>
                </div>;
        }

        let sort = null;
        if (this.props.enableSorting) {
            sort =
                <div style={{display: "inline-block"}}>
                    <div onClick={this.onSortRequested.bind(this, 'asc' , this.props.column.colId)} onTouchEnd={this.onSortRequested.bind(this, 'asc')} className={`customSortDownLabel ${this.state.ascSort}`}>
                        <i class="fa fa-long-arrow-alt-down">A</i>
                    </div>
                    <div onClick={this.onSortRequested.bind(this, 'desc' , this.props.column.colId)} onTouchEnd={this.onSortRequested.bind(this, 'desc')} className={`customSortUpLabel ${this.state.descSort}`}>
                        <i class="fa fa-long-arrow-alt-up">B</i>
                    </div>
                    <div onClick={this.onSortRequested.bind(this, '', this.props.column.colId)} onTouchEnd={this.onSortRequested.bind(this, '')} className={`customSortRemoveLabel ${this.state.noSort}`}>
                       X <i class="fa fa-times">X</i>
                    </div>
                </div>;
        }

        return (
            <div>
                {menu}
                <div className="customHeaderLabel">{this.props.displayName}</div>
                {sort}
            </div>
        );
    }

    onMenuClicked() {
        this.props.showColumnMenu(this.menuButton);
    }

    onSortChanged() {
        this.setState({
            ascSort: this.props.column.isSortAscending() ? 'active' : 'inactive',
            descSort: this.props.column.isSortDescending() ? 'active' : 'inactive',
            noSort: !this.props.column.isSortAscending() && !this.props.column.isSortDescending() ? 'active' : 'inactive'
        });
    }

    onMenuClick() {
        this.props.showColumnMenu(this.menuButton);
    }

    onSortRequested(order, displayName, event) {
        console.log(order,'order');
        console.log(event,'event');
        console.log(displayName,'displayName');
        console.log(event.shiftKey,'event.shiftKey');
        const customObject = {colId:displayName,sort:order};
        this.props.agGridReact.props.storeSortState(customObject);
        // this.props.setSort(order, event.shiftKey);
    }
}