import React from "react";
import { Route, IndexRoute } from "react-router";
import App from "./components/App";
import HomePage from "./components/home/HomePage";
import AboutPage from "./components/about/AboutPage";
import SummaryDetails from "./components/Summary/SummaryDetails";
import { CourseContainer } from "src/containers/courses_container";
import { pieChartDataContainer } from "src/containers/pieChartData_container";

export default (
  <Route path="/" component={App}>
    <IndexRoute component={HomePage} />
    <Route path="coursesnew" component={CourseContainer} />
    <Route path="pieChart" component={pieChartDataContainer} />
    <Route path="about" component={AboutPage} />
     <Route path="summarydetails" component={SummaryDetails} /> 
  </Route>
);
