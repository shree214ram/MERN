import React, { Component } from 'react';
import { AgGridReact } from 'ag-grid-react';
import { AllCommunityModules } from "@ag-grid-community/all-modules";
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import CustomHeader from "./customHeader.js";

class HomePage extends Component {
  constructor(props) {
    super(props);

    this.state = {
      savedSort: [],
      modules: AllCommunityModules,
      columnDefs: [
        {
          headerName: "Athlete",
          field: "athlete",
          width: 125,
          suppressMenu: true
        },
        {
          headerName: "Age",
          field: "age",
          width: 90,
          sortable: false,
          headerComponentParams: { menuIcon: "fa-external-link-alt" }
        },
        {
          headerName: "Country",
          field: "country",
          width: 120,
          suppressMenu: true
        },
        {
          headerName: "Year",
          field: "year",
          width: 90,
          sortable: false
        },
        {
          headerName: "Date",
          field: "date",
          width: 100,
          suppressMenu: true
        },
        {
          headerName: "Sport",
          field: "sport",
          width: 90,
          sortable: false
        },
        {
          headerName: "Gold",
          field: "gold",
          width: 115,
          headerComponentParams: { menuIcon: "fa-cog" }
        },
        {
          headerName: "Silver",
          field: "silver",
          width: 90,
          sortable: false
        },
        {
          headerName: "Bronze",
          field: "bronze",
          width: 115,
          suppressMenu: true
        },
        {
          headerName: "Total",
          field: "total",
          width: 90,
          sortable: false
        }
      ],
      rowData: null,
      frameworkComponents: { agColumnHeader: CustomHeader },
      multiSortKey: "ctrl",
      defaultColDef: {
        width: 100,
        headerComponentParams: { menuIcon: "fa-bars" },
        sortable: true,
        resizable: true,
        filter: true
      }
    };
  }

  storeSortState = myObj => {
    console.log(myObj, 'myObj');
    var oldSavedSort = this.state.savedSort;
    console.log(myObj, 'myObj');
    const index = oldSavedSort.findIndex((e) => e.colId === myObj.colId);
    console.log(index, 'index');
    if (index === -1) {
      if(myObj.order !== null){
        oldSavedSort.push(myObj);
      } else {
        oldSavedSort.remove(oldSavedSort[index]);
      }
    } else {
      oldSavedSort[index] = myObj;
    }
    console.log(oldSavedSort, 'oldSavedSort');
    this.setState({ savedSort: oldSavedSort });
  }

  onGridReady = params => {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

    const httpRequest = new XMLHttpRequest();
    const updateData = data => {
      this.setState({ rowData: data });
    };

    httpRequest.open(
      "GET",
      "https://raw.githubusercontent.com/ag-grid/ag-grid/master/packages/ag-grid-docs/src/olympicWinnersSmall.json"
    );
    httpRequest.send();
    httpRequest.onreadystatechange = () => {
      if (httpRequest.readyState === 4 && httpRequest.status === 200) {
        updateData(JSON.parse(httpRequest.responseText));
      }
    };
  };

  clearSort() {
    this.gridApi.setSortModel(null);
  }

  saveSort() {
    const newLatestSort = this.state.savedSort;
    console.log("newLatestSort sort==: " + JSON.stringify(newLatestSort));
    this.gridApi.setSortModel(newLatestSort);
  }


  myCustomHeader() {
    const greeting = 'Hello Function Component!';
    return this.Headline(greeting);
  }

  Headline({ value }) {
    return <h1>{value}</h1>;
  }

  render() {
    return (
      <div style={{ width: "100%", height: "100%" }}>
        <div style={{ marginBottom: "5px" }}>

          <div style={{ marginTop: "5px" }}>
            <button onClick={this.clearSort.bind(this)}>Clear Sort</button>
            <button onClick={this.saveSort.bind(this)}>Save Sort</button>
          </div>
        </div>
        <div style={{ height: "calc(100% - 60px)" }}>
          <div
            className="ag-theme-balham"
            style={{
              height: '500px',
              width: '100%'
            }}
          >

            <AgGridReact
              modules={this.state.modules}
              columnDefs={this.state.columnDefs}
              rowData={this.state.rowData}
              suppressMenuHide={true}
              frameworkComponents={this.state.frameworkComponents}
              defaultColDef={this.state.defaultColDef}
              onGridReady={this.onGridReady}
              multiSortKey={this.state.multiSortKey}
              storeSortState={this.storeSortState}
            />
          </div>
        </div>
      </div>

    );
  }
}

export default HomePage;