
import * as React from 'react'
import {useState} from 'react'

const LocationsNewFormComponent = ({ props, binCode }) => {
    return (
        <>
            <Section noPadding="true" title="" className="bin-status-container">
                <Flex between container grow={1} className="summary-wrapper">
                    <div className="summary-container">
                        <Flex column container>
                            <Text.H4 weight="lighter" className="summary-header mrgn-2px f-w-400">Bin ID</Text.H4>
                            <Text.H3 className="mrgn-2px f-w-400">{binCode}</Text.H3>
                        </Flex>
                    </div>
                    <div className="summary-container">
                        <Flex container column>
                            <Text.H4 weight="lighter" className="right-summary-header mrgn-2px f-w-400">Items</Text.H4>
                            <Text.H3 className="mrgn-2px f-w-400 bin-summary-item">{props.binItem.binItemCode.length}</Text.H3>
                        </Flex>
                    </div>
                </Flex>
            </Section>
        </>
    )
}

export default LocationsNewFormComponent;

