import React from 'react';
import Section from '@myntra/uikit-component-section';
import Text from '@myntra/uikit-component-text';
import { Flex, Loader } from '@myntra/uikit';
import InputMonth from '@myntra/uikit-component-input-month';
import Modal from '@myntra/uikit-component-modal';
import ScanBarCodeComponent from '../../../babylon/utils/react/components/scan-barcode-component';
import { getDateTime, getYearDifference, getUpdateDateObject } from '../util/bin-consolidation-common-util';
import { Button } from '@myntra/uikit';

class BinConsolidationBinSummary extends React.Component {
    constructor(props) {
        super(props);
        this.onToggle = this.onToggle.bind(this);
        this.state = {
            currentScannedItem: null,
            prevScannedItemObject: { "itemExpiryInfoEntry": { "itemId": "", "mfgDate": "", "expiryDate": "" } },
            hasDateErrorExists: false,
            mfgDate: {},
            mfgOpen: false,
            expOpen: false,
            selectedMfgDate: null,
            selectedExpDate: null,
            confirmBinChecked: true,
            showItemScan: true
        };
    }

    componentWillMount() {
        if (!String.prototype.padStart) {
            String.prototype.padStart = function padStart(targetLength, padString) {
                targetLength = targetLength >> 0; //truncate if number, or convert non-number to 0;
                padString = String(typeof padString !== 'undefined' ? padString : ' ');
                if (this.length >= targetLength) {
                    return String(this);
                } else {
                    targetLength = targetLength - this.length;
                    if (targetLength > padString.length) {
                        padString += padString.repeat(targetLength / padString.length); //append to original to ensure we are longer than needed
                    }
                    return padString.slice(0, targetLength) + String(this);
                }
            };
        }
    }
    
    searchItem = (itemCode) => {
        this.setState({ currentScannedItem: itemCode, selectedMfgDate: null, selectedExpDate: null });

        const { enableScanBinConsolidationin } = this.props;
        this.props.searchItemAgainstBinCode(itemCode, enableScanBinConsolidationin);
    }
   
    
    render() {
        const { binCode } = this.props;
        const scanItemBarProps = {
            placeholder: 'SCAN ITEMS',
            type: 'small',
            maxLength: this.props.maxLength,
            showToggle    : this.props.isKeyboardEnabled ? this.props.isMobile : false,
            onToggle: this.onToggle,
            keyboardState: this.props.keyboardState,
            onEnter: this.searchItem
        };
        const scanConfirmBinProps = {
            value: '',
            placeholder: 'SCAN BIN TO CONFIRM',
            type: 'small',
            maxLength: this.props.maxLength,
            showToggle    : this.props.isKeyboardEnabled ? this.props.isMobile : false,
            onEnter: this.postItems,
            keyboardState: this.props.keyboardState
        };
        return (
            <div>
                <Section noPadding="true" title="" className="bin-status-container">
                    <Flex between container grow={1} className="summary-wrapper">
                        <div className="summary-container">
                            <Flex column container>
                                <Text.H4 weight="lighter" className="summary-header mrgn-2px f-w-400">Bin ID</Text.H4>
                                <Text.H3 className="mrgn-2px f-w-400">{binCode}</Text.H3>
                            </Flex>
                        </div>
                        <div className="summary-container">
                            <Flex container column>
                                <Text.H4 weight="lighter" className="right-summary-header mrgn-2px f-w-400">Items</Text.H4>
                                <Text.H3 className="mrgn-2px f-w-400 bin-summary-item">{this.props.binItem.binItemCode.length}</Text.H3>
                            </Flex>
                        </div>
                    </Flex>
                </Section>

                <div>
                    {this.state.showItemScan ?
                        <div className="item-scan-wrapper">
                            <ScanBarCodeComponent {...scanItemBarProps} />
                        </div>
                        :
                        null
                    }

                    <div className="scrollDiv" >
                        {
                            this.props.binItem.isBinItemFetching ?
                                <div>
                                    <Loader type="small" />
                                </div>
                                :
                                this.props.binItem.isItemFetchSuccess &&
                                this.props.binItem.binItemCode.map((item, index) => {
                                    return (
                                        <Section noPadding="true" title="" className="bin-status-container" key={index}>
                                            <Flex between container grow={1} className="summary-wrapper" >
                                                <Text.H3 className="mrgn-2px  f-w-400">#{this.props.binItem.binItemCode.length - index}</Text.H3>
                                                <div className="summary-container">
                                                    <Flex column container>
                                                        <Text.H3 className="mrgn-2px f-w-400">{item}</Text.H3>
                                                    </Flex>
                                                </div>
                                            </Flex>
                                        </Section>
                                    )
                                })
                        }
                    </div>
                </div>
            </div>
        )
    }
}

export default BinConsolidationBinSummary