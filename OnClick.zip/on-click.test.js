import * as React from 'react'
import {render, screen} from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import Question  from '../on-click'

const { open } = window;

  beforeAll(() => {
    // Delete the existing
    delete window.open;
    // Replace with the custom value
    window.open = jest.fn();
    // Works for `location` too, eg:
    // window.location = { origin: 'http://localhost:3100' };
  });

  afterAll(() => {
    // Restore original
    window.open = open;
  });

test('clicking the button toggles an answer on/off', () => {
    render(<Question question="Is RTL great?" answer="Yes, it is." />);
    const button = screen.getByRole('button')
    const text = screen.getByTestId('question')
    
    userEvent.click(button)
    expect(screen.getByText('Yes, it is.')).toBeInTheDocument()
    
    userEvent.click(button)
    expect(screen.queryByText('Yes, it is.')).not.toBeInTheDocument()

    userEvent.click(text)
    const target = "https://google.com" 
    // const newWindow = window.open(target, '_self');
    // expect(newWindow).toHaveBeenCalled()
    // expect(newWindow).toHaveBeenCalledWith(target)

//     global.open = jest.fn();
//   statementService.openStatementsReport(111);
//   expect(global.open).toBeCalled();

// const open = jest.fn()
// Object.defineProperty(window, 'open', open);

// window.open = jest.fn()
// ...code
// expect(window.open).toHaveBeenCalledTimes(1)




// expect(window.open).toHaveBeenCalledWith('/new-tab','__blank')

// global.open = jest.fn();
//   statementService.openStatementsReport(111);
//   expect(global.open).toBeCalled();

// statementService.openStatementsReport(111)
//   expect(windowOpen).toBeCalled();
// statementService.openStatementsReport(111);
    expect(window.open).toBeCalled(); // Happy happy, joy joy

    // expect(screen.queryByText('Back To Search')).not.toBeInTheDocument()
})